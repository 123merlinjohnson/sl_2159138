package javaassignment;

import java.util.Random;
import java.util.Scanner;

public class Advice {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();

        
        String[] answers = {
            "Yes",
            "No",
            "Maybe",
            "Try again later"
        };

        
        System.out.println("Ask me a question:");
        scanner.nextLine(); 
        int index = random.nextInt(answers.length);
        String selectedAnswer = answers[index];
        System.out.println("Answer: " + selectedAnswer);

        scanner.close();
    }
}

