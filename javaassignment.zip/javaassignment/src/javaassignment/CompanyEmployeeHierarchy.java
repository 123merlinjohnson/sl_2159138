package javaassignment;


class Employeew {
    protected String name;
    protected String address;
    protected double salary;
    protected String jobTitle;

    
    public Employeew(String name, String address, double salary, String jobTitle) {
        this.name = name;
        this.address = address;
        this.salary = salary;
        this.jobTitle = jobTitle;
    }


    public double calculateBonus() {
        return 0;
    }

    public void generatePerformanceReport() {
        System.out.println("Performance report for " + name + " is generated.");
    }

    public void manageProjects() {
        System.out.println("Projects are managed by " + jobTitle + " " + name + ".");
    }
}

class Manager extends Employeew {
    public String department;

    public Manager(String name, String address, double salary, String jobTitle, String department) {
        super(name, address, salary, jobTitle);
        this.department = department;
    }

    @Override
    public double calculateBonus() {
        return salary * 0.1; 
    }
}

class Developer extends Employeew {
    public String programmingLanguage;

    public Developer(String name, String address, double salary, String jobTitle, String programmingLanguage) {
        super(name, address, salary, jobTitle);
        this.programmingLanguage = programmingLanguage;
    }
        @Override
        public double calculateBonus() {
            return salary * 0.1; 
        }
    
    

    @Override
    public void generatePerformanceReport() {
        System.out.println("Performance report for " + name + " (Developer) is generated.");
    }
}

class Programmer extends Developer {
    public String specialization;

    public Programmer(String name, String address, double salary, String jobTitle, String programmingLanguage, String specialization) {
        super(name, address, salary, jobTitle, programmingLanguage);
        this.specialization = specialization;
    }
    @Override
    public double calculateBonus() {
        return salary * 0.1; 
    }
}


public class CompanyEmployeeHierarchy {
    public static void main(String[] args) {
        Manager manager = new Manager("John ", "ABC", 80000, "Manager", "IT");
        Developer developer = new Developer("Jane ", "BCD", 60000, "Developer", "Java");
        Programmer programmer = new Programmer("Alex ", "EGG", 70000, "Programmer", "Python", "Web Development");

        System.out.println(manager.name + " bonus: $" + manager.calculateBonus());
        System.out.println(developer.name + " bonus: $" + developer.calculateBonus());
        System.out.println(programmer.name + " bonus: $" + programmer.calculateBonus());

        manager.generatePerformanceReport();
        developer.generatePerformanceReport();
        programmer.generatePerformanceReport();

        manager.manageProjects();
        developer.calculateBonus();
        developer.manageProjects();
        programmer.manageProjects();
        programmer.calculateBonus();
        
    }
}

  