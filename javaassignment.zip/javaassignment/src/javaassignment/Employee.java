package javaassignment;


public class Employee {
    private double salary;
    private int hoursOfWorkPerDay;

    public void getInfo(double salary, int hoursOfWorkPerDay) {
        this.salary = salary;
        this.hoursOfWorkPerDay = hoursOfWorkPerDay;
    }

    public void AddSal() {
        if (salary < 1500.3) {
            salary += 1000;
        }
    }

    public void AddWork() {
        if (hoursOfWorkPerDay > 6) {
            salary += 500;
        }
    }

    public void printFinalSalary() {
        System.out.println("Final Salary: " + salary);
    }

    public static void main(String[] args) {
        Employee emp = new Employee();
        emp.getInfo(1200, 8); 
        emp.AddSal();
        emp.AddWork();
        emp.printFinalSalary();
    }
}