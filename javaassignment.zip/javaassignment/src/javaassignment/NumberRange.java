package javaassignment;

import java.util.Scanner;

public class NumberRange {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
       
        System.out.print("Enter the start number: ");
        int start = scanner.nextInt();
        System.out.print("Enter the end number: ");
        int end = scanner.nextInt();

        System.out.println("Numbers from " + start + " to " + end + ":");
        for (int i = start; i <= end; i++) {
            System.out.println(i);
        }

        scanner.close();
    }
}
