package javaassignment;
import java.util.List;

public class StringTrimmer {
    public static void trimStrings(List<String> strings) {
        for (int i = 0; i < strings.size(); i++) {
            String trimmedString = strings.get(i).trim();
            strings.set(i, trimmedString);
        }
    }

    public static void main(String[] args) {
        // Example usage
        List<String> words = List.of("   Hello  ", "  World  ", "   Java  ");
        System.out.println("Before trimming:");
        System.out.println(words);

        trimStrings(words);

        System.out.println("\nAfter trimming:");
        System.out.println(words);
    }
}
