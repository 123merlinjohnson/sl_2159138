package javaassignment;



public class Triangle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		TargetShape triangle = new TargetShape();
	    triangle.setSide1(2);
	    triangle.setSide2(6);
	    triangle.setSide3(7);
	    double side1 = triangle.getSide1();
	    double side2 = triangle.getSide2();
	    double side3 = triangle.getSide3();
	    calculateArea(side1, side2, side3);
	    double answer = calculatePerimeter(side1, side2, side3);
	    System.out.println("perimeter is " + answer);
		    
	}
   public static void calculateArea(double side1, double side2, double side3) {
	        double s = (side1 + side2 + side3) / 2;
	       double answer= Math.sqrt(s * (s - side1) * (s - side2) * (s - side3));
	       System.out.println("area is" + answer);
	    }

	    
	    public static double calculatePerimeter(double side1, double side2, double side3) {
	        
	    	return side1 + side2 + side3;
	    }
}

 class TargetShape {
    private double side1;
    private double side2;
    private double side3;

    public TargetShape(double side1, double side2, double side3) {
        this.side1 = side1;
        this.side2 = side2;
        this.side3 = side3;
    }

    public TargetShape()
    {
    	
    }
    public void setSide1(double side1) {
        this.side1 = side1;
    }

    public void setSide2(double side2) {
        this.side2 = side2;
    }

    public void setSide3(double side3) {
        this.side3 = side3;
    }

   
    public double getSide1() {
        return side1;
    }

    public double getSide2() {
        return side2;
    }

    public double getSide3() {
        return side3;
    }
}
